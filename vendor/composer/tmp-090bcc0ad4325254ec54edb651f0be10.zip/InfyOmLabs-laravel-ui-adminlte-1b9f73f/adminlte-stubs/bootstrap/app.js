require('./bootstrap');
require('admin-lte');
